// 무한이동 클릭형 배너 JS - index.js
