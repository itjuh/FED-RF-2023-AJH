// 레오폴드 메뉴 데이터
export const menuData = ["KEYBOARD", "SWITCH", "LOGIN", "REGISTER", "WISHLIST", "CONTACT"];
