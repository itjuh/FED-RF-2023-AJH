import { CartCon, GlassCon, UserCon } from "../modules/Icons";

export const gnbData = [
    {txt : 'SEARCH',
        com:<GlassCon />},
    {txt : 'LOGIN',
        com:<UserCon />},
    {txt : 'LOGOUT',
        com:<UserCon />},
    {txt : 'WISHLIST',
        com:<CartCon />},
]