// context API
import { createContext } from "react";

export const LeoCon = createContext();